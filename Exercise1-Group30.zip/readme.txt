Task RT1.1: Implementation of Ray-Plane Intersections
	- Verify if the plane and ray are parallel using the dot product (return false if that is the case).
	- Otherwise, compute the intersection and the distance 't' to the intersection point.
	- Check if the distance is negative (behind the viewer) or too far away.
	- Finally, check if we are on the correct side of the plane.
	
	- Problem encountered: 
		- We did not check if we were on the correct face of the plane at the end, resulting in an incorrect result.

Task RT1.2.1: Derivation of the Expression for a Ray-Cylinder Intersection
	- Assume a cylinder of infinite height.
	- Project the ray onto the plane x, y.
	- Solve the intersection between the projected ray and the circle formed in the plane x, y by the cylinder.
	- Once we have the candidate point, check its height. If it is within the cylinder height, it is an intersection point.

Task RT1.2.2: Implementation of Ray-Cylinder Intersections
	- Solve the quadratic equation found in RT1.2.1.
	- For each possible solution (a maximum of two), check if the candidate point is within the cylinder height. If it is, update t and 	intersection normal and take the smaller t.
	- Finally, check if the normal is oriented towards the viewer.
	
- Problems encountered: 
		- At the beginning we did not check for the orientation of the normal yielding to a wrong result.
		- We could not loop for I < num_solutions because num_solutions is not a constant so we temporarily fixed it replacing num_solutions with 2. 

CONTRIBUTIONS:

Antonio Jimenez: 34%
Theo Abel: 33%
Jules: 33%

	